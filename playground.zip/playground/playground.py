from flask import Flask, render_template
app = Flask(__name__)

@app.route("/play")
def welcome():
    print("welcome")
    return render_template("play.html", num_times = 3)

@app.route("/play/<x>")
def boxes(x):
    num = int(x)
    return render_template("play.html", num_times = int(x))

@app.route("/play/<x>/<color>")
def color(x, color):
    # num = int(x)
    # div_color = color
    return render_template("play.html", num_times = int(x), color_type = color )

if __name__=="__main__":
    app.run(debug=True)